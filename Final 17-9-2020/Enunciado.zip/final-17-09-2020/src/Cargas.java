public enum Cargas {
    HELATODO, BICI;
}

public interface Carga {

    boolean puedeSerCargadaPorClasico();

    boolean puedeSerCargadaPorCargaConBici();
}

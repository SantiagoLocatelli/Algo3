public enum KaiohKen {
    KAIOH_KEN, KAIOH_KEN_X3, SIN_KAIOH_KEN
}

public class PortaCargaVacioError extends Error {
}

public class VehiculoNoAdmiteCargaError extends Error{
}

public interface PortaCarga {

    void cargar(Carga carga);

    Carga descargar();
}

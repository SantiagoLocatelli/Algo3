public class Helatodo implements Carga {

    public Helatodo(){

    }

    public boolean puedeSerCargadaPorClasico(){
        return true;
    }

    public boolean puedeSerCargadaPorCargaConBici(){
        return true;
    }
}
